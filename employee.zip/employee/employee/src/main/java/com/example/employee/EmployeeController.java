package com.example.employee;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class EmployeeController {

  @Autowired
  private EmployeeService service;

  @GetMapping("/")
  public String home(Model model) {
    model.addAttribute("employees", service.getAll());
    return "index";
  }

  @GetMapping("/add")
  public String addForm(Model model) {
    model.addAttribute("employee", new Employee());
    return "add-employee";
  }

  @PostMapping("/save")
  public String save(@ModelAttribute Employee employee) {
    service.save(employee);
    return "redirect:/";
  }

  @GetMapping("/edit/{id}")
  public String editForm(@PathVariable Long id, Model model) {
    model.addAttribute("employee", service.getById(id));
    return "edit-employee";
  }

  @PostMapping("/update")
  public String update(@ModelAttribute Employee employee) {
    service.save(employee);
    return "redirect:/";
  }

  @GetMapping("/delete/{id}")
  public String delete(@PathVariable Long id) {
    service.delete(id);
    return "redirect:/";
  }
  
  

} 