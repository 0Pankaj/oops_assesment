package com.example.volunteer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolunteerApplicationTests {

	@Test
	void contextLoads() {
	}

}
